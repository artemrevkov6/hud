PLUGIN.name = "Modern UI"
PLUGIN.author = "Товарищ Джеймс 'Zaku' Дикенсон"
PLUGIN.description = "Wow, how nice!"
PLUGIN.license = [[
╔══════════════════════════════════════════════════════════════════════════════════════════════╗
║                 (c) 2019-2022 by Zaku ( https://discord.gg/BcjUr6M )                         ║
╠══════════════════════════════════════════════════════════════════════════════════════════════╣
║                        Feel free to edit and use this plugin                                 ║
║                                                                                              ║
║                      Please don't write to me about this plugin.                             ║
║                       Because I don't play Garry's Mod anymore                               ║
║                                                                                              ║
║            The plugin was created by "Товарищ Джеймс 'Zaku' Дикенсон #2137"                  ║
╚══════════════════════════════════════════════════════════════════════════════════════════════╝
]]

-- READ, README FILE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ty